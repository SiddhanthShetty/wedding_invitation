# Sweekruti & Siddhanth — wedding invitation

A mobile-first wedding invitation website with a Royal Mangalorean / coastal heritage design:
landing page, the six events, venue and travel, a Carnatic music player, RSVP with a private
admin page, countdown, gallery, and a QR code with print layouts.

Nothing about the wedding is invented. Dates, times, venues, contacts and photographs are
placeholders until you fill them in.

## Contents

1. [Run it on your computer](#1-run-it-on-your-computer)
2. [Fill in the wedding details](#2-fill-in-the-wedding-details)
3. [Set up RSVP storage (Supabase)](#3-set-up-rsvp-storage-supabase)
4. [Set up the admin page](#4-set-up-the-admin-page)
5. [Going live (Vercel or Netlify)](#5-going-live)
6. [QR code and printing](#6-qr-code-and-printing)
7. [Music](#7-music)
8. [Photos](#8-photos)
9. [Testing](#9-testing)
10. [How it is built](#10-how-it-is-built)
11. [Security and privacy notes](#11-security-and-privacy-notes)

## 1. Run it on your computer

Needs Node.js 20.9 or newer.

```bash
npm install
cp .env.example .env.local     # then edit .env.local (see below)
npm run dev                    # http://localhost:3000
```

For a quick local try-out without Supabase, put this in `.env.local`:

```
RSVP_STORAGE=file
ADMIN_PASSWORD=choose-a-long-passphrase
SESSION_SECRET=<output of: openssl rand -base64 48>
```

RSVPs are then written to `.data/rsvps.json` (git-ignored). This file store only works in
development; a deployed site must use Supabase.

Production build:

```bash
npm run build
npm start
```

## 2. Fill in the wedding details

Everything lives in **`src/config/wedding.ts`**. Replace `null` with real values as they are confirmed.

| What | Field | Format |
| --- | --- | --- |
| Wedding day (drives the countdown) | `weddingDate`, `weddingTime` | `"2027-02-14"`, `"10:30"` (24-hour, India time) |
| Each event | `events[n].date`, `startTime`, `endTime` | same formats; the day of the week is worked out for you |
| Each venue | `events[n].venue` | `{ name: "…", address: "…", mapsUrl: null }` |
| Dress code, description | `events[n].dressCode`, `description` | text or `null` |
| Main venue shown in "Venue and Travel" | `mainVenueEventId` | defaults to `"muhuratham"` |
| Airport, railway, hotels, parking, travel contact | `travel` | text, list, or `null` |
| Contact in the footer | `contact` | name / phone / email or `null` |
| RSVP limits | `rsvp.maxGuestsPerInvite`, `rsvp.respondBy` | number, date or `null` |
| Tracks | `music` | see [Music](#7-music) |
| Photos | `gallery` | see [Photos](#8-photos) |

Notes:

- **Directions.** Once a venue has a name and address, its "Get directions" button opens Google Maps
  with that destination, and the main venue shows an embedded map. To point at an exact pin, paste a
  Google Maps share link into `mapsUrl`. If events are at different venues, each gets its own
  directions link.
- **Countdown.** Runs to `weddingDate` at `weddingTime` in `timezone` (Asia/Kolkata). If
  `weddingTime` is `null` it uses the Muhuratham start time, then midnight. While `weddingDate` is
  `null` the site shows "The celebrations are coming soon".
- The six events must stay in their order. The file is validated at build time; a mistake stops the
  build with a message naming the field.
- Wording for the hero, story and footer is in `src/components/Hero.tsx`, `Story.tsx` and `Footer.tsx`.

## 3. Set up RSVP storage (Supabase)

1. Create a project at <https://supabase.com> (the free tier is enough).
2. Open **SQL Editor**, paste the contents of `supabase/migrations/0001_create_rsvps.sql`, and run it.
   (With the Supabase CLI: `supabase link` then `supabase db push`.)
3. In **Project Settings → API**, copy the **Project URL** and the **secret key**
   (`service_role` / `sb_secret_…`).
4. Set them as environment variables:

   ```
   SUPABASE_URL=https://xxxxxxxx.supabase.co
   SUPABASE_SERVICE_ROLE_KEY=…
   ```

The table has Row Level Security switched on with no policies, and the public roles have no
privileges, so guest data can only be read with the secret key, which stays on the server.
One response is kept per email address; sending the form again from the same address updates it.

If storage is not configured, the RSVP form tells the guest it could not be saved. It never shows a
success message for something that was not stored.

## 4. Set up the admin page

Set two more environment variables:

```
ADMIN_PASSWORD=<a passphrase of at least 12 characters>
SESSION_SECRET=<at least 32 random characters, e.g. openssl rand -base64 48>
```

Then open **`/admin`** and sign in. You get attendance counts, guests per event, every response, and
a **Download CSV** button. The session lasts 8 hours. Until both variables are set, `/admin` stays
switched off.

## 5. Going live

### Vercel

1. Push this folder to a GitHub repository and import it at <https://vercel.com/new>
   (or run `npx vercel` in this folder).
2. Under **Settings → Environment Variables**, add for Production:
   `NEXT_PUBLIC_SITE_URL`, `SUPABASE_URL`, `SUPABASE_SERVICE_ROLE_KEY`, `ADMIN_PASSWORD`, `SESSION_SECRET`.
3. Optional: add your own domain under **Settings → Domains**.
4. Set `NEXT_PUBLIC_SITE_URL` to the final address guests will use, for example
   `https://sweekruti-siddhanth.com` or `https://your-project.vercel.app`, then **redeploy**.
   The QR code, link previews and share buttons are built from this value at build time.

### Netlify

Import the repository; Netlify detects Next.js. Add the same environment variables under
**Site configuration → Environment variables**, then redeploy.

### After deploying, check

- [ ] The site opens on `https://…` on a phone.
- [ ] Send a test RSVP; it appears on `/admin`; delete the test row in Supabase afterwards.
- [ ] The "Share the Invitation" section shows a QR code; scan it with an iPhone and an Android phone.
- [ ] Paste the link into WhatsApp; the preview shows the monogram card. (WhatsApp caches previews;
      if you change the image later, test with `?v=2` on the end.)

Search engines are told not to index the site unless you set `NEXT_PUBLIC_ALLOW_INDEXING=true`.

## 6. QR code and printing

The QR code encodes `NEXT_PUBLIC_SITE_URL` and nothing else. The site refuses to produce one for
`localhost`, `file://`, plain `http://`, private addresses, or Vercel/Netlify preview addresses,
so a temporary link cannot end up on printed cards. Until the address is set, the share section
says the code is not available yet.

In the "Share the Invitation" section you can:

- download the code as PNG (1200 px) or SVG (for your card designer),
- open **Print QR code** (`/print/qr`, a small A6 card) or **Print invitation card** (`/print/card`, A5),
- copy the link, or share by WhatsApp or email.

The monogram sits beside the code, never on top of it, and the code keeps its white margin.
`npm test` decodes the generated image and checks it reads back as the exact address. Still, always
print one copy and scan it before a full print run, and re-download the code if the address changes.

## 7. Music

The five tracks in `public/audio` are **original pieces generated by `scripts/generate-music.py`**:
a tanpura drone with an improvised line inside one raga (Hamsadhwani, Mohanam, Kalyani,
Shankarabharanam, Madhyamavati) on a synthesised veena, flute or violin. They are computer-made,
so there is nothing to license, but they are not a substitute for real musicians.

To use real recordings (ones you have recorded or licensed):

1. Put the MP3 (or M4A/OGG) in `public/audio`.
2. In `src/config/wedding.ts`, edit the `music` list: `title`, `raga`, `instrument`, `src`, `credit`.

Music never starts by itself; it loads and plays only when a guest presses play. On iPhones the
on-screen volume slider has no effect (iOS only allows the hardware buttons); mute works everywhere.

`npm run music` regenerates the synthesised tracks (needs Python 3, numpy and ffmpeg).

## 8. Photos

Add files to `public/gallery` and set `src`, `alt`, `width`, `height` in the `gallery` list. Entries
with `src: null` show a clearly labelled placeholder, or an illustration for the "heritage" category.

## 9. Testing

```bash
npm run typecheck
npm test          # 55 unit tests
npm run build
```

The tests cover: the six events and their order, config validation, India-time countdown maths,
directions links, RSVP validation, persistence and de-duplication, admin statistics, CSV export
(including formula-injection defusing), session tokens, the production-URL rules, and decoding the
generated QR code.

Manual checks worth doing after any change:

| Check | How |
| --- | --- |
| Layout at 360, 390, 430, 768, 1024, 1440 px | Browser dev tools → device toolbar; no sideways scrolling |
| Music does not autoplay | Load the page; nothing plays until you press play |
| RSVP validation | Submit empty; errors appear and focus moves to the first one |
| RSVP is stored | Submit, then look at `/admin` |
| Duplicate protection | Submit twice with the same email; one row, updated |
| Admin is private | Open `/admin/export` in a private window; you get "Not signed in" |
| Keyboard | Tab through nav, player, form, gallery (Esc and arrow keys in the lightbox) |
| Reduced motion | Turn on "Reduce motion" in the OS; entrance and flame animations stop |

## 10. How it is built

- **Next.js 16** (App Router, React 19, TypeScript), **Tailwind CSS 4**, **Motion** (Framer Motion)
  for the menu, lightbox and form transitions, **Lucide** icons.
- **Supabase (Postgres)** for RSVPs, reached only from the server (`src/lib/storage`).
- **zod** validates both the config file and RSVP submissions (same schema in the browser and on the server).
- **qrcode** generates the QR at build time.
- All artwork (monogram, tiled-roof house, coastal temple, palms, lamps, jasmine, event
  illustrations) is hand-written SVG in `src/components/art.tsx` and `src/lib/monogram-svg.ts`.
  Fonts (Cormorant Garamond, Marcellus; SIL Open Font License) are self-hosted from `src/fonts`.

```
src/
  config/wedding.ts        ← the one file to edit
  app/
    page.tsx               the invitation (all sections)
    layout.tsx             fonts, SEO and social metadata
    api/rsvp/route.ts      RSVP endpoint
    admin/                 sign-in, dashboard, CSV export
    print/card, print/qr   printable layouts
    opengraph-image.tsx    link-preview image (WhatsApp, X, etc.)
    icon.svg               favicon (regenerate: node scripts/make-icon.ts)
  components/              Hero, Story, Events, Venue, Music, Rsvp, Countdown, Gallery, Share, Footer, art
  lib/                     dates, maps links, QR, validation, storage, sessions, CSV
supabase/migrations/       database schema
scripts/                   music and icon generators
tests/                     unit tests
```

## 11. Security and privacy notes

- No secrets are in the code. Server secrets are read from environment variables and never sent to
  the browser; only `NEXT_PUBLIC_*` values are public.
- RSVP input is validated on the server, limited in size, and rate-limited per IP address
  (6 submissions per 10 minutes). A hidden honeypot field catches simple bots. The limiter is
  in-memory, so on serverless hosting it is per instance; if you ever see spam, add Vercel's
  firewall rate-limit rule or a CAPTCHA.
- Anyone who knows a guest's email address could overwrite that guest's response by submitting again.
  That is the trade-off for letting guests correct their own reply without an account.
- The admin cookie is HTTP-only, `SameSite=Strict`, `Secure` in production, signed with
  `SESSION_SECRET`, and limited to `/admin`. Sign-in attempts are limited to 5 per 15 minutes.
  Changing `SESSION_SECRET` signs everyone out.
- `/admin` and `/api` responses are sent with `Cache-Control: no-store`.
- Guest data is personal data. Share the admin passphrase only with people who need it, and delete
  the Supabase project (or the table) once the wedding is over.
