// Regenerates src/app/icon.svg from the shared monogram artwork:  node scripts/make-icon.ts
import { writeFileSync } from "node:fs";
import { monogramSvg } from "../src/lib/monogram-svg.ts";

writeFileSync(new URL("../src/app/icon.svg", import.meta.url), monogramSvg("seal", "icon").replace(' aria-hidden="true"', "") + "\n");
console.log("wrote src/app/icon.svg");
