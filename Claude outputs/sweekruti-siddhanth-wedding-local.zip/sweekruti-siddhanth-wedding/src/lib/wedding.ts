import { weddingConfig, type Venue, type WeddingEvent } from "@/config/wedding";
import { zonedDateTimeToUtc } from "./datetime";

export function directionsUrl(venue: Venue): string {
  if (venue.mapsUrl) return venue.mapsUrl;
  return `https://www.google.com/maps/dir/?api=1&destination=${encodeURIComponent(`${venue.name}, ${venue.address}`)}`;
}

export function mapEmbedUrl(venue: Venue): string {
  return `https://www.google.com/maps?q=${encodeURIComponent(`${venue.name}, ${venue.address}`)}&output=embed`;
}

export function eventById(id: WeddingEvent["id"]): WeddingEvent {
  return weddingConfig.events.find((e) => e.id === id)!;
}

/** Instant the countdown runs to, or null while the date is unannounced. */
export function weddingInstant(config = weddingConfig): Date | null {
  if (!config.weddingDate) return null;
  const muhuratham = config.events.find((e) => e.id === "muhuratham");
  const time =
    config.weddingTime ?? (muhuratham?.date === config.weddingDate ? muhuratham.startTime : null) ?? "00:00";
  return zonedDateTimeToUtc(config.weddingDate, time, config.timezone);
}

/** Distinct venues across events, each with the events held there. */
export function venuesWithEvents(config = weddingConfig): { venue: Venue; events: WeddingEvent[] }[] {
  const out: { venue: Venue; events: WeddingEvent[] }[] = [];
  for (const e of config.events) {
    if (!e.venue) continue;
    const key = `${e.venue.name}|${e.venue.address}`.toLowerCase();
    const hit = out.find((v) => `${v.venue.name}|${v.venue.address}`.toLowerCase() === key);
    if (hit) hit.events.push(e);
    else out.push({ venue: e.venue, events: [e] });
  }
  return out;
}
