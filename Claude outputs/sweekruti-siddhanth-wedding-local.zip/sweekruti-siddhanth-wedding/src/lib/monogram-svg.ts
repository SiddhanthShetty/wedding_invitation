/**
 * The SS monogram as an SVG string, so the same artwork serves the page, the
 * favicon, the print layouts and the social preview image.
 * The letterform is the capital S of Cormorant Garamond SemiBold Italic (SIL OFL).
 */
const S_PATH =
  "M189 -12Q154 -12 118 -4Q83 3 44 22Q40 25 38 30Q36 34 38 41L64 179Q64 184 70 184Q75 184 75 179Q84 126 102 88Q120 50 148 30Q176 9 215 9Q244 9 268 22Q293 34 310 58Q327 81 332 117Q340 161 326 193Q311 225 284 250Q257 276 226 298Q195 321 167 346Q139 371 124 404Q110 436 118 481Q129 534 162 568Q195 602 240 619Q286 636 334 636Q360 636 389 630Q418 625 448 612Q462 605 460 595L446 472Q445 468 440 468Q435 468 434 472Q427 514 410 546Q394 579 370 598Q345 617 311 617Q278 617 256 602Q234 587 222 564Q209 542 205 520Q198 480 212 452Q226 423 252 400Q279 377 308 354Q341 330 371 303Q401 276 418 241Q434 206 426 159Q417 112 387 73Q357 34 308 11Q258 -12 189 -12Z";

export type MonogramTone = "dark" | "light" | "seal";

const TONES: Record<MonogramTone, { ground: string; disc: string | null; first: string; second: string; line: string }> = {
  // On maroon and other dark grounds.
  dark: { ground: "#421319", disc: null, first: "#B58A45", second: "#E7CE98", line: "#B58A45" },
  // On ivory and paper.
  light: { ground: "#FBF3E4", disc: null, first: "#8A6426", second: "#B58A45", line: "#9A7434" },
  // Self-contained: carries its own maroon disc. Used for the favicon and previews.
  seal: { ground: "#421319", disc: "#421319", first: "#B58A45", second: "#E7CE98", line: "#B58A45" },
};

export function monogramSvg(tone: MonogramTone = "dark", id = "ss"): string {
  const t = TONES[tone];
  const petals = Array.from({ length: 24 }, (_, i) =>
    `<path transform="rotate(${i * 15} 100 100)" d="M100 7.5c4.2 4.6 4.2 9.4 0 13.5c-4.2-4.1-4.2-8.9 0-13.5Z"/>`,
  ).join("");
  const beads = Array.from({ length: 48 }, (_, i) => {
    const a = (i * 7.5 * Math.PI) / 180;
    return `<circle cx="${(100 + 71 * Math.sin(a)).toFixed(2)}" cy="${(100 - 71 * Math.cos(a)).toFixed(2)}" r="0.9"/>`;
  }).join("");
  const s = (tx: number, ty: number, fill: string, extra = "") =>
    `<path transform="translate(${tx} ${ty}) scale(0.132 -0.132)" d="${S_PATH}" fill="${fill}" stroke="${t.ground}" stroke-width="11" paint-order="stroke" ${extra}/>`;
  return [
    `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 200 200" width="100%" height="100%" aria-hidden="true">`,
    t.disc ? `<circle cx="100" cy="100" r="100" fill="${t.disc}"/>` : "",
    `<defs><clipPath id="${id}-top"><rect x="0" y="0" width="200" height="97"/></clipPath></defs>`,
    `<g fill="none" stroke="${t.line}">`,
    `<circle cx="100" cy="100" r="96" stroke-width="1.4"/>`,
    `<g stroke-width="1">${petals}</g>`,
    `<circle cx="100" cy="100" r="76" stroke-width="1.6"/>`,
    `</g>`,
    `<g fill="${t.line}">${beads}</g>`,
    // Small sprigs at the foot of the ring.
    `<g fill="none" stroke="${t.line}" stroke-width="1.2" stroke-linecap="round">`,
    `<path d="M100 163c-9 1-17-2-23-8"/><path d="M100 163c9 1 17-2 23-8"/>`,
    `<path d="M88 161c-1-4-4-6-8-6"/><path d="M112 161c1-4 4-6 8-6"/>`,
    `</g>`,
    `<path d="M100 157l3.4 5l-3.4 5l-3.4-5Z" fill="${t.second}"/>`,
    `<path d="M100 33l3 4.5l-3 4.5l-3-4.5Z" fill="${t.second}"/>`,
    s(52, 132, t.first),
    s(82, 146, t.second),
    // Re-draw the top of the first S over the second so the two letters interlace.
    s(52, 132, t.first, `clip-path="url(#${id}-top)"`),
    `</svg>`,
  ].join("");
}
