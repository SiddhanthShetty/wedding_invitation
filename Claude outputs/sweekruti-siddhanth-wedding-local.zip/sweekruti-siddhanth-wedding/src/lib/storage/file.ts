import "server-only";
import { randomUUID } from "node:crypto";
import { mkdir, readFile, rename, writeFile } from "node:fs/promises";
import path from "node:path";
import type { RsvpInput } from "@/lib/rsvp-schema";
import type { RsvpRecord, RsvpStore } from "./types";

/** Local-development store. Writes to .data/rsvps.json, which is git-ignored. */
export function fileStore(file = path.join(/* turbopackIgnore: true */ process.cwd(), ".data", "rsvps.json")): RsvpStore {
  let queue: Promise<unknown> = Promise.resolve();

  async function read(): Promise<RsvpRecord[]> {
    try {
      return JSON.parse(await readFile(/* turbopackIgnore: true */ file, "utf8")) as RsvpRecord[];
    } catch (e) {
      if ((e as NodeJS.ErrnoException).code === "ENOENT") return [];
      throw e;
    }
  }

  return {
    kind: "file",
    save(input: RsvpInput) {
      const run = queue.then(async () => {
        const all = await read();
        const now = new Date().toISOString();
        const existing = all.find((r) => r.email === input.email);
        const next: RsvpRecord = {
          id: existing?.id ?? randomUUID(),
          createdAt: existing?.createdAt ?? now,
          updatedAt: now,
          fullName: input.fullName,
          email: input.email,
          phone: input.phone,
          attending: input.attending === "accept",
          guestCount: input.guestCount,
          events: input.events,
          dietary: input.dietary,
          dietaryNotes: input.dietaryNotes,
          message: input.message,
        };
        const rest = all.filter((r) => r.email !== input.email);
        await mkdir(/* turbopackIgnore: true */ path.dirname(file), { recursive: true });
        await writeFile(/* turbopackIgnore: true */ `${file}.tmp`, JSON.stringify([next, ...rest], null, 2), { mode: 0o600 });
        await rename(/* turbopackIgnore: true */ `${file}.tmp`, /* turbopackIgnore: true */ file);
      });
      queue = run.catch(() => undefined);
      return run;
    },
    async list() {
      return (await read()).sort((a, b) => b.createdAt.localeCompare(a.createdAt));
    },
  };
}
