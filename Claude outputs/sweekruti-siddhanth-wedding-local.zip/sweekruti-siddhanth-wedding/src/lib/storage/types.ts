import type { RsvpInput } from "@/lib/rsvp-schema";

export interface RsvpRecord {
  id: string;
  createdAt: string;
  updatedAt: string;
  fullName: string;
  email: string;
  phone: string;
  attending: boolean;
  guestCount: number;
  events: string[];
  dietary: string;
  dietaryNotes: string;
  message: string;
}

export interface RsvpStore {
  readonly kind: "supabase" | "file";
  /** Insert, or replace the earlier response from the same email address. */
  save(input: RsvpInput): Promise<void>;
  list(): Promise<RsvpRecord[]>;
}
