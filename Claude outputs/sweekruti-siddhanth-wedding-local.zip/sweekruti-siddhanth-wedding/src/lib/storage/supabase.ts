import "server-only";
import { createClient, type SupabaseClient } from "@supabase/supabase-js";
import type { RsvpInput } from "@/lib/rsvp-schema";
import type { RsvpRecord, RsvpStore } from "./types";

type Row = {
  id: string;
  created_at: string;
  updated_at: string;
  full_name: string;
  email: string;
  phone: string;
  attending: boolean;
  guest_count: number;
  events: string[];
  dietary: string;
  dietary_notes: string;
  message: string;
};

let client: SupabaseClient | null = null;

export function supabaseStore(url: string, serviceKey: string): RsvpStore {
  client ??= createClient(url, serviceKey, { auth: { persistSession: false, autoRefreshToken: false } });
  const db = client;
  return {
    kind: "supabase",
    async save(input: RsvpInput) {
      const { error } = await db.from("rsvps").upsert(
        {
          full_name: input.fullName,
          email: input.email,
          phone: input.phone,
          attending: input.attending === "accept",
          guest_count: input.guestCount,
          events: input.events,
          dietary: input.dietary,
          dietary_notes: input.dietaryNotes,
          message: input.message,
          updated_at: new Date().toISOString(),
        },
        { onConflict: "email" },
      );
      if (error) throw new Error(`Supabase save failed: ${error.message}`);
    },
    async list(): Promise<RsvpRecord[]> {
      const { data, error } = await db.from("rsvps").select("*").order("created_at", { ascending: false }).limit(5000);
      if (error) throw new Error(`Supabase read failed: ${error.message}`);
      return ((data ?? []) as Row[]).map((r) => ({
        id: r.id,
        createdAt: r.created_at,
        updatedAt: r.updated_at,
        fullName: r.full_name,
        email: r.email,
        phone: r.phone,
        attending: r.attending,
        guestCount: r.guest_count,
        events: r.events ?? [],
        dietary: r.dietary,
        dietaryNotes: r.dietary_notes ?? "",
        message: r.message ?? "",
      }));
    },
  };
}
