/**
 * ─────────────────────────────────────────────────────────────────────────────
 *  THE ONE FILE TO EDIT
 *
 *  Every name, date, time, venue, travel note, track and gallery photo on the
 *  site comes from `weddingDetails` below. Leave a value as `null` until it is
 *  known and the site shows a tasteful "to be announced" in its place.
 *
 *  Dates are "YYYY-MM-DD", times are 24-hour "HH:MM", both in `timezone`.
 *  The file is checked when the site builds; a typo stops the build with a
 *  message naming the field.
 * ─────────────────────────────────────────────────────────────────────────────
 */
import { z } from "zod";

export const EVENT_IDS = ["engagement", "haldi", "mehendi", "sangeet", "muhuratham", "reception"] as const;
export type EventId = (typeof EVENT_IDS)[number];

const isoDate = z.string().regex(/^\d{4}-(0[1-9]|1[0-2])-(0[1-9]|[12]\d|3[01])$/, "Use YYYY-MM-DD");
const clockTime = z.string().regex(/^([01]\d|2[0-3]):[0-5]\d$/, "Use 24-hour HH:MM");
const text = z.string().trim().min(1);

const venueSchema = z.object({
  name: text,
  /** Complete postal address, as you would write it on an envelope. */
  address: text,
  /** Optional: paste a Google Maps share link. If null, a directions link is built from the name and address. */
  mapsUrl: z.url().nullable().default(null),
});

const eventSchema = z
  .object({
    id: z.enum(EVENT_IDS),
    name: text,
    date: isoDate.nullable(),
    startTime: clockTime.nullable(),
    endTime: clockTime.nullable(),
    venue: venueSchema.nullable(),
    description: text.nullable(),
    dressCode: text.nullable(),
  })
  .refine((e) => !(e.endTime && !e.startTime), { message: "endTime needs a startTime", path: ["endTime"] })
  .refine((e) => !(e.startTime && !e.date), { message: "startTime needs a date", path: ["startTime"] });

const trackSchema = z.object({
  title: text,
  raga: text,
  instrument: text,
  /** Path under /public, e.g. "/audio/hamsadhwani.mp3". Replace the file or change the path. */
  src: z.string().startsWith("/"),
  credit: text,
});

const galleryItemSchema = z.object({
  category: z.enum(["couple", "engagement", "family", "preparations", "heritage"]),
  /** Path under /public, e.g. "/gallery/couple-1.jpg". null shows a clearly marked placeholder. */
  src: z.string().startsWith("/").nullable(),
  alt: text,
  width: z.number().int().positive().default(1200),
  height: z.number().int().positive().default(1500),
});

const configSchema = z
  .object({
    brideName: text,
    groomName: text,
    monogram: text,
    /** The wedding day (the Muhuratham). Drives the countdown. */
    weddingDate: isoDate.nullable(),
    /** Time the countdown runs to. If null, the Muhuratham start time is used, else midnight. */
    weddingTime: clockTime.nullable(),
    timezone: z.string().refine((tz) => {
      try {
        new Intl.DateTimeFormat("en", { timeZone: tz });
        return true;
      } catch {
        return false;
      }
    }, "Unknown timezone"),
    location: text,
    /** The event whose venue is shown as the main wedding venue. */
    mainVenueEventId: z.enum(EVENT_IDS),
    events: z.array(eventSchema).length(6),
    travel: z.object({
      airport: text.nullable(),
      railway: text.nullable(),
      accommodation: z.array(z.object({ name: text, note: text.nullable(), url: z.url().nullable() })),
      parking: text.nullable(),
      assistanceContact: z.object({ name: text, phone: text }).nullable(),
    }),
    contact: z.object({ name: text.nullable(), phone: text.nullable(), email: z.email().nullable() }),
    rsvp: z.object({ maxGuestsPerInvite: z.number().int().min(1).max(20), respondBy: isoDate.nullable() }),
    music: z.array(trackSchema).min(1),
    gallery: z.array(galleryItemSchema),
  })
  .refine((c) => c.events.every((e, i) => e.id === EVENT_IDS[i]), {
    message: `events must stay in this order: ${EVENT_IDS.join(", ")}`,
    path: ["events"],
  })
  .refine((c) => !(c.weddingTime && !c.weddingDate), { message: "weddingTime needs a weddingDate", path: ["weddingTime"] });

export type WeddingConfigInput = z.input<typeof configSchema>;
export type WeddingConfig = z.output<typeof configSchema>;
export type WeddingEvent = WeddingConfig["events"][number];
export type Venue = NonNullable<WeddingEvent["venue"]>;
export type Track = WeddingConfig["music"][number];
export type GalleryItem = WeddingConfig["gallery"][number];

const weddingDetails: WeddingConfigInput = {
  brideName: "Sweekruti",
  groomName: "Siddhanth",
  monogram: "SS",

  weddingDate: null, // e.g. "2027-02-14"
  weddingTime: null, // e.g. "10:30"
  timezone: "Asia/Kolkata",
  location: "Mangaluru, Karnataka, India",

  mainVenueEventId: "muhuratham",

  // Keep these six in this order. Fill in each as details are confirmed.
  events: [
    {
      id: "engagement",
      name: "Engagement",
      date: null,
      startTime: null,
      endTime: null,
      venue: null, // e.g. { name: "…", address: "…", mapsUrl: null }
      description: "Rings, blessings and the first promise, with both our families gathered around us.",
      dressCode: null,
    },
    {
      id: "haldi",
      name: "Haldi",
      date: null,
      startTime: null,
      endTime: null,
      venue: null,
      description: "Turmeric, marigolds and a good deal of laughter. Wear something you don't mind turning yellow.",
      dressCode: null,
    },
    {
      id: "mehendi",
      name: "Mehendi",
      date: null,
      startTime: null,
      endTime: null,
      venue: null,
      description: "An unhurried afternoon of henna, songs and stories.",
      dressCode: null,
    },
    {
      id: "sangeet",
      name: "Sangeet",
      date: null,
      startTime: null,
      endTime: null,
      venue: null,
      description: "An evening of music and dance from both sides of the family.",
      dressCode: null,
    },
    {
      id: "muhuratham",
      name: "Muhuratham",
      date: null,
      startTime: null,
      endTime: null,
      venue: null,
      description: "The wedding ceremony, at the auspicious hour, in the presence of our elders.",
      dressCode: null,
    },
    {
      id: "reception",
      name: "Reception",
      date: null,
      startTime: null,
      endTime: null,
      venue: null,
      description: "Dinner, good company and a chance for us to thank you in person.",
      dressCode: null,
    },
  ],

  travel: {
    // General pointers for the city in `location`. Edit or set to null.
    airport: "Mangaluru International Airport (IXE) is the nearest airport.",
    railway: "Mangaluru Central and Mangaluru Junction are the city's two main railway stations.",
    accommodation: [], // e.g. [{ name: "Hotel name", note: "10 minutes from the venue", url: "https://…" }]
    parking: null, // e.g. "Parking is available at the venue."
    assistanceContact: null, // e.g. { name: "…", phone: "+91 …" }
  },

  contact: { name: null, phone: null, email: null },

  rsvp: { maxGuestsPerInvite: 6, respondBy: null },

  // Original instrumental pieces generated for this site (see scripts/generate-music.py).
  // To use your own recording, drop the file in public/audio and point `src` at it.
  music: [
    { title: "Mangala Arambha", raga: "Hamsadhwani", instrument: "Veena", src: "/audio/hamsadhwani.mp3", credit: "Original synthesised piece" },
    { title: "Kadala Theera", raga: "Mohanam", instrument: "Flute", src: "/audio/mohanam.mp3", credit: "Original synthesised piece" },
    { title: "Sandhya Deepa", raga: "Kalyani", instrument: "Violin", src: "/audio/kalyani.mp3", credit: "Original synthesised piece" },
    { title: "Mallige", raga: "Shankarabharanam", instrument: "Veena", src: "/audio/shankarabharanam.mp3", credit: "Original synthesised piece" },
    { title: "Mangalam", raga: "Madhyamavati", instrument: "Flute", src: "/audio/madhyamavati.mp3", credit: "Original synthesised piece" },
  ],

  // src: null shows a labelled placeholder. Add real photos to public/gallery and set src.
  gallery: [
    { category: "couple", src: null, alt: "Photograph of Sweekruti and Siddhanth" },
    { category: "heritage", src: null, alt: "Illustration of a tiled-roof Mangalorean home among coconut palms" },
    { category: "engagement", src: null, alt: "Photograph from the engagement" },
    { category: "family", src: null, alt: "Photograph of our families" },
    { category: "heritage", src: null, alt: "Illustration of a coastal Karnataka temple with a lamp tower" },
    { category: "preparations", src: null, alt: "Photograph of the wedding preparations" },
    { category: "couple", src: null, alt: "Photograph of Sweekruti and Siddhanth" },
    { category: "heritage", src: null, alt: "Illustration of the Arabian Sea at dusk" },
  ],
};

function load(): WeddingConfig {
  const parsed = configSchema.safeParse(weddingDetails);
  if (!parsed.success) {
    const lines = parsed.error.issues.map((i) => `  • ${i.path.join(".") || "(config)"}: ${i.message}`);
    throw new Error(`src/config/wedding.ts has a problem:\n${lines.join("\n")}`);
  }
  return parsed.data;
}

export const weddingConfig = load();
export { configSchema };

export const coupleNames = `${weddingConfig.brideName} & ${weddingConfig.groomName}`;
