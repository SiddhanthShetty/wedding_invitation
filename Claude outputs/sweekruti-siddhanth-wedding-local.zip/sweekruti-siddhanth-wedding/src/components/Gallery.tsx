"use client";

import { ChevronLeft, ChevronRight, ImageIcon, X } from "lucide-react";
import { AnimatePresence, motion } from "motion/react";
import Image from "next/image";
import { useCallback, useEffect, useRef, useState } from "react";
import type { GalleryItem } from "@/config/wedding";
import { DAY, HouseAndPalms, SeaAtDusk, TempleAndPalms } from "./art";
import { SectionHeading } from "./Section";

const CATEGORY_LABEL: Record<GalleryItem["category"], string> = {
  couple: "The couple",
  engagement: "Engagement",
  family: "Family",
  preparations: "Wedding preparations",
  heritage: "Coastal heritage",
};

type Tile = GalleryItem & { art: number | null };

function Picture({ item, large = false }: { item: Tile; large?: boolean }) {
  if (item.src) {
    return (
      <Image
        src={item.src}
        alt={item.alt}
        width={item.width}
        height={item.height}
        loading="lazy"
        sizes={large ? "(min-width: 1024px) 60vw, 92vw" : "(min-width: 1024px) 25vw, (min-width: 640px) 33vw, 50vw"}
        className={large ? "max-h-[78svh] w-auto max-w-full object-contain" : "size-full object-cover"}
      />
    );
  }
  if (item.art !== null) {
    const art = item.art % 3;
    return (
      <div role="img" aria-label={item.alt} className={`relative grid place-items-end overflow-hidden ${art === 2 ? "bg-maroon" : "bg-parchment"} ${large ? "aspect-[4/5] h-[min(70svh,34rem)] max-w-full" : "size-full"}`}>
        {art === 0 ? <HouseAndPalms tone={DAY} className="w-[130%] max-w-none -translate-x-[12%]" /> : null}
        {art === 1 ? <TempleAndPalms tone={DAY} className="w-[130%] max-w-none -translate-x-[10%]" /> : null}
        {art === 2 ? <SeaAtDusk className="absolute inset-0 size-full" /> : null}
        <span className="absolute top-2 left-2 bg-ivory/90 px-2 py-0.5 font-label text-[0.72rem] text-maroon">Illustration</span>
      </div>
    );
  }
  return (
    <div role="img" aria-label={`Placeholder: ${item.alt}`} className={`grid place-items-center bg-parchment p-3 text-center ${large ? "aspect-[4/5] h-[min(70svh,34rem)] max-w-full" : "size-full"}`}>
      <div className="grid size-full place-items-center border border-dashed border-gold-deep/70 p-3">
        <div>
          <ImageIcon className="mx-auto size-8 text-gold-deep" aria-hidden="true" />
          <p className="mt-2 font-label text-[0.95rem]">{CATEGORY_LABEL[item.category]}</p>
          <p className="mt-0.5 text-[0.92rem] text-maroon/70 italic">Photo placeholder</p>
        </div>
      </div>
    </div>
  );
}

export function Gallery({ items }: { items: GalleryItem[] }) {
  let artCount = 0;
  const tiles: Tile[] = items.map((it) => ({ ...it, art: !it.src && it.category === "heritage" ? artCount++ : null }));
  const [open, setOpen] = useState<number | null>(null);
  const opener = useRef<HTMLElement | null>(null);
  const closeButton = useRef<HTMLButtonElement>(null);

  const close = useCallback(() => {
    setOpen(null);
    opener.current?.focus();
  }, []);
  const move = useCallback((by: number) => setOpen((i) => (i === null ? i : (i + by + tiles.length) % tiles.length)), [tiles.length]);

  useEffect(() => {
    if (open === null) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") close();
      if (e.key === "ArrowRight") move(1);
      if (e.key === "ArrowLeft") move(-1);
    };
    document.addEventListener("keydown", onKey);
    document.body.style.overflow = "hidden";
    closeButton.current?.focus();
    return () => {
      document.removeEventListener("keydown", onKey);
      document.body.style.overflow = "";
    };
  }, [open === null, close, move]); // eslint-disable-line react-hooks/exhaustive-deps

  const current = open === null ? null : tiles[open]!;

  return (
    <section id="gallery" aria-labelledby="gallery-title" className="bg-ivory px-5 py-20 sm:py-28">
      <SectionHeading id="gallery-title" title="Moments" lead="Photographs will be added here as the celebrations approach." />
      <ul className="mx-auto grid max-w-5xl grid-cols-2 gap-2.5 sm:grid-cols-3 sm:gap-4 lg:grid-cols-4">
        {tiles.map((item, i) => (
          <li key={i} className="aspect-[4/5]">
            <button
              type="button"
              onClick={(e) => {
                opener.current = e.currentTarget;
                setOpen(i);
              }}
              className="block size-full overflow-hidden border border-gold/70 transition-transform duration-300 hover:scale-[1.015]"
              aria-label={`Open ${item.src || item.art !== null ? "" : "placeholder for "}${CATEGORY_LABEL[item.category].toLowerCase()} image ${i + 1} of ${tiles.length}`}
            >
              <Picture item={item} />
            </button>
          </li>
        ))}
      </ul>

      <AnimatePresence>
        {current && open !== null ? (
          <motion.div
            role="dialog"
            aria-modal="true"
            aria-label={`${CATEGORY_LABEL[current.category]}, image ${open + 1} of ${tiles.length}`}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
            className="fixed inset-0 z-50 flex items-center justify-center bg-maroon-deep/95 p-4"
            onClick={close}
          >
            <motion.figure
              key={open}
              initial={{ opacity: 0, scale: 0.97 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.25 }}
              className="flex max-h-full max-w-full flex-col items-center"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="border border-gold">
                <Picture item={current} large />
              </div>
              <figcaption className="mt-3 text-center font-label text-[0.95rem] text-champagne">
                {CATEGORY_LABEL[current.category]} ({open + 1} of {tiles.length})
              </figcaption>
            </motion.figure>
            <button ref={closeButton} type="button" onClick={close} aria-label="Close" className="absolute top-3 right-3 grid size-12 place-items-center rounded-full border border-gold/70 bg-maroon text-ivory">
              <X className="size-5" aria-hidden="true" />
            </button>
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                move(-1);
              }}
              aria-label="Previous image"
              className="absolute bottom-4 left-4 grid size-12 place-items-center rounded-full border border-gold/70 bg-maroon text-ivory sm:top-1/2 sm:bottom-auto sm:-translate-y-1/2"
            >
              <ChevronLeft className="size-5" aria-hidden="true" />
            </button>
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                move(1);
              }}
              aria-label="Next image"
              className="absolute right-4 bottom-4 grid size-12 place-items-center rounded-full border border-gold/70 bg-maroon text-ivory sm:top-1/2 sm:bottom-auto sm:-translate-y-1/2"
            >
              <ChevronRight className="size-5" aria-hidden="true" />
            </button>
          </motion.div>
        ) : null}
      </AnimatePresence>
    </section>
  );
}
