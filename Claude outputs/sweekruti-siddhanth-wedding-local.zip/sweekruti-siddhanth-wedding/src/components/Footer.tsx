import { coupleNames, weddingConfig } from "@/config/wedding";
import { formatDate } from "@/lib/datetime";
import { siteUrl } from "@/lib/site-url";
import { BrassLamp, Divider } from "./art";
import { CopyLink } from "./CopyLink";
import { Monogram } from "./Monogram";

export function Footer() {
  const { weddingDate, location, contact } = weddingConfig;
  const date = weddingDate ? formatDate(weddingDate) : null;
  const hasContact = contact.name || contact.phone || contact.email;
  return (
    <footer className="relative isolate overflow-hidden bg-maroon-deep px-5 pt-16 pb-10 text-center text-ivory">
      <div className="paisley absolute inset-0 -z-10 opacity-[0.06]" />
      <div className="mx-auto flex max-w-3xl items-end justify-center gap-6 sm:gap-10">
        <BrassLamp className="h-28 sm:h-36" />
        <div>
          <Monogram tone="dark" className="w-24 sm:w-28" label="S S monogram" />
          <p className="mt-3 font-display text-[clamp(1.9rem,7vw,2.6rem)] leading-tight italic">{coupleNames}</p>
        </div>
        <BrassLamp className="h-28 sm:h-36" />
      </div>
      <Divider className="mt-6" />
      <p className="mx-auto mt-6 max-w-md text-[1.15rem] text-ivory/90 italic">
        With love, tradition and a little coastal magic. We can&rsquo;t wait to celebrate with you.
      </p>
      <dl className="mx-auto mt-8 grid max-w-2xl gap-6 font-label text-[0.98rem] sm:grid-cols-3">
        <div>
          <dt className="text-champagne">Date</dt>
          <dd className="mt-1 font-display text-[1.1rem]">{date ? `${date.weekday}, ${date.long}` : "To be announced"}</dd>
        </div>
        <div>
          <dt className="text-champagne">Place</dt>
          <dd className="mt-1 font-display text-[1.1rem]">{location}</dd>
        </div>
        <div>
          <dt className="text-champagne">Contact</dt>
          <dd className="mt-1 font-display text-[1.1rem]">
            {hasContact ? (
              <>
                {contact.name ? <span className="block">{contact.name}</span> : null}
                {contact.phone ? (
                  <a className="block underline decoration-gold underline-offset-4" href={`tel:${contact.phone.replace(/[^+\d]/g, "")}`}>
                    {contact.phone}
                  </a>
                ) : null}
                {contact.email ? (
                  <a className="block break-all underline decoration-gold underline-offset-4" href={`mailto:${contact.email}`}>
                    {contact.email}
                  </a>
                ) : null}
              </>
            ) : (
              "Details to follow"
            )}
          </dd>
        </div>
      </dl>
      <div className="mt-8">
        {siteUrl.ok ? (
          <CopyLink url={siteUrl.url} label="Copy the invitation link" />
        ) : (
          <a href="#share" className="btn btn-line">
            Share the invitation
          </a>
        )}
      </div>
      <p className="mt-10 text-[0.95rem] text-ivory/65">
        &copy; {new Date().getFullYear()} {coupleNames}. Made with love for our families and friends.
      </p>
    </footer>
  );
}
