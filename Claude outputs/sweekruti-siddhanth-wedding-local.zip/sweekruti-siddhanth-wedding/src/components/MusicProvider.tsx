"use client";

import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import type { Track } from "@/config/wedding";

type MusicState = {
  tracks: Track[];
  index: number;
  playing: boolean;
  muted: boolean;
  volume: number;
  time: number;
  duration: number;
  error: string | null;
  toggle: () => void;
  select: (index: number) => void;
  step: (by: number) => void;
  seek: (seconds: number) => void;
  setVolume: (v: number) => void;
  setMuted: (m: boolean) => void;
};

const Ctx = createContext<MusicState | null>(null);

export function useMusic(): MusicState {
  const v = useContext(Ctx);
  if (!v) throw new Error("useMusic must be used inside <MusicProvider>");
  return v;
}

/**
 * Owns the page's single <audio> element. Nothing loads or plays until the
 * guest presses play: preload is "none" and there is no autoplay anywhere.
 */
export function MusicProvider({ tracks, children }: { tracks: Track[]; children: ReactNode }) {
  const audio = useRef<HTMLAudioElement>(null);
  const [index, setIndex] = useState(0);
  const [playing, setPlaying] = useState(false);
  const [muted, setMutedState] = useState(false);
  const [volume, setVolumeState] = useState(0.8);
  const [time, setTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [error, setError] = useState<string | null>(null);
  const wantPlay = useRef(false);

  const play = useCallback(() => {
    const el = audio.current;
    if (!el) return;
    wantPlay.current = true;
    setError(null);
    el.play().catch((e: unknown) => {
      if ((e as DOMException)?.name === "AbortError") return;
      wantPlay.current = false;
      setError("The music could not be played on this device.");
    });
  }, []);

  const toggle = useCallback(() => {
    const el = audio.current;
    if (!el) return;
    if (el.paused) play();
    else {
      wantPlay.current = false;
      el.pause();
    }
  }, [play]);

  const select = useCallback(
    (next: number) => {
      const i = ((next % tracks.length) + tracks.length) % tracks.length;
      wantPlay.current = true;
      if (i === index) play();
      else setIndex(i);
    },
    [index, play, tracks.length],
  );

  const step = useCallback(
    (by: number) => {
      const keep = wantPlay.current || !audio.current?.paused;
      const i = (((index + by) % tracks.length) + tracks.length) % tracks.length;
      wantPlay.current = keep;
      setIndex(i);
    },
    [index, tracks.length],
  );

  // A new track was chosen: load it, and carry on playing only if the guest had already started the music.
  const first = useRef(true);
  useEffect(() => {
    if (first.current) {
      first.current = false;
      return;
    }
    const el = audio.current;
    if (!el) return;
    setTime(0);
    setDuration(0);
    el.load();
    if (wantPlay.current) play();
  }, [index, play]);

  useEffect(() => {
    if (audio.current) audio.current.volume = volume;
  }, [volume]);
  useEffect(() => {
    if (audio.current) audio.current.muted = muted;
  }, [muted]);

  const value = useMemo<MusicState>(
    () => ({
      tracks,
      index,
      playing,
      muted,
      volume,
      time,
      duration,
      error,
      toggle,
      select,
      step,
      seek: (s) => {
        if (audio.current && Number.isFinite(s)) audio.current.currentTime = s;
      },
      setVolume: (v) => {
        setVolumeState(Math.min(1, Math.max(0, v)));
        if (v > 0) setMutedState(false);
      },
      setMuted: setMutedState,
    }),
    [tracks, index, playing, muted, volume, time, duration, error, toggle, select, step],
  );

  return (
    <Ctx.Provider value={value}>
      {children}
      <audio
        ref={audio}
        src={tracks[index]?.src}
        preload="none"
        onPlay={() => setPlaying(true)}
        onPause={() => setPlaying(false)}
        onTimeUpdate={(e) => setTime(e.currentTarget.currentTime)}
        onLoadedMetadata={(e) => setDuration(e.currentTarget.duration)}
        onDurationChange={(e) => setDuration(e.currentTarget.duration)}
        onEnded={() => {
          wantPlay.current = true;
          setIndex((i) => (i + 1) % tracks.length);
        }}
        onError={() => {
          wantPlay.current = false;
          setPlaying(false);
          setError("This track could not be loaded.");
        }}
      />
    </Ctx.Provider>
  );
}
