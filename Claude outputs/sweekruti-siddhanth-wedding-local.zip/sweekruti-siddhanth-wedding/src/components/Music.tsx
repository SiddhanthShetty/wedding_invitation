"use client";

import { Pause, Play, SkipBack, SkipForward, Volume2, VolumeX } from "lucide-react";
import { useMusic } from "./MusicProvider";
import { SectionHeading } from "./Section";

const clock = (s: number) => (Number.isFinite(s) && s > 0 ? `${Math.floor(s / 60)}:${String(Math.floor(s % 60)).padStart(2, "0")}` : "0:00");

// Heights and timings for the visualiser's strings; fixed so server and browser render the same.
const BARS = [0.5, 0.8, 0.62, 1, 0.7, 0.9, 0.55, 0.76, 1, 0.6, 0.86, 0.66, 0.95, 0.58, 0.8, 0.7, 1, 0.64, 0.84, 0.52, 0.9, 0.68, 0.78, 0.56];

export function Music() {
  const m = useMusic();
  const track = m.tracks[m.index]!;
  return (
    <section id="music" aria-labelledby="music-title" className="relative isolate overflow-hidden bg-maroon px-5 py-20 text-ivory sm:py-28">
      <div className="paisley absolute inset-0 -z-10 opacity-[0.07]" />
      <SectionHeading
        id="music-title"
        tone="dark"
        title="Music for the Occasion"
        lead="Five short instrumental pieces in ragas loved at Carnatic weddings. Press play whenever you would like some music while you read."
      />

      <div className="mx-auto max-w-2xl border border-gold/60 bg-maroon-deep/70 p-5 sm:p-8">
        <div className={`flex h-20 items-end justify-center gap-[5px] ${m.playing ? "viz-playing" : ""}`} aria-hidden="true">
          {BARS.map((h, i) => (
            <span
              key={i}
              className="viz-bar w-[5px] rounded-t-full bg-gold"
              style={{ height: `${h * 100}%`, ["--d" as string]: `${0.9 + ((i * 7) % 10) / 10}s`, ["--o" as string]: `${-((i * 13) % 17) / 10}s` }}
            />
          ))}
        </div>

        <div className="mt-6 text-center" aria-live="polite">
          <p className="font-display text-[1.9rem] leading-tight italic">{track.title}</p>
          <p className="mt-1 font-label text-[0.98rem] text-champagne">
            Raga {track.raga}, {track.instrument.toLowerCase()}
          </p>
        </div>

        <div className="mt-6 flex items-center gap-3 font-label text-[0.85rem] text-champagne tabular-nums">
          <span className="w-10 text-right">{clock(m.time)}</span>
          <input
            type="range"
            min={0}
            max={m.duration || 0}
            step={1}
            value={Math.min(m.time, m.duration || 0)}
            onChange={(e) => m.seek(Number(e.target.value))}
            disabled={!m.duration}
            aria-label="Position in track"
            aria-valuetext={`${clock(m.time)} of ${clock(m.duration)}`}
            className="h-11 min-w-0 flex-1 accent-gold"
          />
          <span className="w-10">{clock(m.duration)}</span>
        </div>

        <div className="mt-3 flex items-center justify-center gap-4">
          <button type="button" onClick={() => m.step(-1)} className="grid size-12 place-items-center rounded-full border border-gold/60 hover:bg-gold/15" aria-label="Previous track">
            <SkipBack className="size-5" aria-hidden="true" />
          </button>
          <button
            type="button"
            onClick={m.toggle}
            className="grid size-16 place-items-center rounded-full bg-gold text-maroon-deep hover:bg-champagne"
            aria-label={m.playing ? "Pause music" : "Play music"}
          >
            {m.playing ? <Pause className="size-7" aria-hidden="true" /> : <Play className="size-7 translate-x-0.5" aria-hidden="true" />}
          </button>
          <button type="button" onClick={() => m.step(1)} className="grid size-12 place-items-center rounded-full border border-gold/60 hover:bg-gold/15" aria-label="Next track">
            <SkipForward className="size-5" aria-hidden="true" />
          </button>
        </div>

        <div className="mx-auto mt-5 flex max-w-xs items-center gap-3">
          <button
            type="button"
            onClick={() => m.setMuted(!m.muted)}
            aria-pressed={m.muted}
            aria-label={m.muted ? "Unmute" : "Mute"}
            className="grid size-11 shrink-0 place-items-center rounded-full border border-gold/60 hover:bg-gold/15"
          >
            {m.muted || m.volume === 0 ? <VolumeX className="size-5" aria-hidden="true" /> : <Volume2 className="size-5" aria-hidden="true" />}
          </button>
          <input
            type="range"
            min={0}
            max={1}
            step={0.05}
            value={m.muted ? 0 : m.volume}
            onChange={(e) => m.setVolume(Number(e.target.value))}
            aria-label="Volume"
            aria-valuetext={`${Math.round((m.muted ? 0 : m.volume) * 100)} percent`}
            className="h-11 min-w-0 flex-1 accent-gold"
          />
        </div>

        {m.error ? (
          <p role="alert" className="mt-4 text-center text-champagne">
            {m.error}
          </p>
        ) : null}

        <ol className="mt-7 divide-y divide-gold/25 border-y border-gold/25">
          {m.tracks.map((t, i) => {
            const current = i === m.index;
            return (
              <li key={t.src}>
                <button
                  type="button"
                  onClick={() => (current ? m.toggle() : m.select(i))}
                  aria-current={current ? "true" : undefined}
                  className={`flex min-h-12 w-full items-center gap-3 px-2 py-2.5 text-left hover:bg-gold/10 ${current ? "text-champagne" : ""}`}
                >
                  <span className="grid size-7 shrink-0 place-items-center">
                    {current && m.playing ? <Pause className="size-4" aria-hidden="true" /> : <Play className="size-4" aria-hidden="true" />}
                  </span>
                  <span className="min-w-0 flex-1">
                    <span className="block truncate">{t.title}</span>
                    <span className="block font-label text-[0.82rem] text-ivory/70">
                      Raga {t.raga}, {t.instrument.toLowerCase()}
                    </span>
                  </span>
                </button>
              </li>
            );
          })}
        </ol>
        <p className="mt-4 text-center text-[0.98rem] text-ivory/70">
          These pieces were composed and synthesised for this invitation. On iPhone, use the side buttons to change the volume.
        </p>
      </div>
    </section>
  );
}
