import { useId } from "react";
import { monogramSvg, type MonogramTone } from "@/lib/monogram-svg";

/** The SS monogram. `tone` picks the colouring for the ground it sits on. */
export function Monogram({ tone = "dark", className = "", label }: { tone?: MonogramTone; className?: string; label?: string }) {
  const id = useId().replace(/[^a-zA-Z0-9]/g, "");
  return (
    <span
      className={`inline-block aspect-square ${className}`}
      role={label ? "img" : undefined}
      aria-label={label}
      aria-hidden={label ? undefined : true}
      dangerouslySetInnerHTML={{ __html: monogramSvg(tone, `m${id}`) }}
    />
  );
}
