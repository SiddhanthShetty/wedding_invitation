import { BedDouble, CarFront, Navigation, Phone, Plane, TrainFront } from "lucide-react";
import type { ReactNode } from "react";
import { weddingConfig } from "@/config/wedding";
import { directionsUrl, eventById, mapEmbedUrl, venuesWithEvents } from "@/lib/wedding";
import { Corner } from "./art";
import { SectionHeading } from "./Section";

function Note({ icon, title, children }: { icon: ReactNode; title: string; children: ReactNode }) {
  return (
    <div className="flex gap-4 border-t border-gold/40 py-5">
      <span className="mt-1 text-champagne">{icon}</span>
      <div className="min-w-0">
        <h3 className="font-label text-[1.05rem] text-champagne">{title}</h3>
        <div className="mt-1 text-ivory/90">{children}</div>
      </div>
    </div>
  );
}

const soon = <span className="text-ivory/70 italic">Details will be shared soon.</span>;

export function Venue() {
  const main = eventById(weddingConfig.mainVenueEventId);
  const venues = venuesWithEvents();
  const { travel } = weddingConfig;
  return (
    <section id="venue" aria-labelledby="venue-title" className="bg-forest px-5 py-20 text-ivory sm:py-28">
      <SectionHeading id="venue-title" tone="dark" title="Venue and Travel" lead={`The wedding will be held in ${weddingConfig.location}.`} />
      <div className="mx-auto grid max-w-5xl gap-12 lg:grid-cols-2">
        <div>
          <div className="relative border border-gold/60 bg-forest-deep p-6 sm:p-8">
            <Corner className="absolute top-1.5 left-1.5 size-9" />
            <Corner className="absolute top-1.5 right-1.5 size-9 rotate-90" />
            <Corner className="absolute right-1.5 bottom-1.5 size-9 rotate-180" />
            <Corner className="absolute bottom-1.5 left-1.5 size-9 -rotate-90" />
            <p className="font-label text-[0.95rem] text-champagne">Main wedding venue ({main.name})</p>
            {main.venue ? (
              <>
                <p className="mt-2 font-display text-[1.9rem] leading-tight">{main.venue.name}</p>
                <address className="mt-1 text-ivory/90 not-italic">{main.venue.address}</address>
                <iframe
                  title={`Map of ${main.venue.name}`}
                  src={mapEmbedUrl(main.venue)}
                  loading="lazy"
                  referrerPolicy="no-referrer-when-downgrade"
                  className="mt-5 aspect-[4/3] w-full border border-gold/50"
                />
                <a href={directionsUrl(main.venue)} target="_blank" rel="noopener noreferrer" className="btn btn-gold mt-5">
                  <Navigation className="size-4" aria-hidden="true" />
                  Get directions<span className="sr-only"> (opens Google Maps)</span>
                </a>
              </>
            ) : (
              <>
                <p className="mt-2 font-display text-[1.9rem] leading-tight">To be confirmed</p>
                <p className="mt-2 text-ivory/80">The address, a map and directions will appear here as soon as the venue is confirmed.</p>
              </>
            )}
          </div>

          {venues.length > 1 ? (
            <div className="mt-8">
              <h3 className="font-label text-[1.05rem] text-champagne">Directions for each event</h3>
              <ul className="mt-2 divide-y divide-gold/30 border-y border-gold/30">
                {venues.map(({ venue, events }) => (
                  <li key={`${venue.name}${venue.address}`} className="flex flex-wrap items-center justify-between gap-3 py-3">
                    <span className="min-w-0">
                      <span className="block">{events.map((e) => e.name).join(", ")}</span>
                      <span className="block text-[1rem] text-ivory/75">{venue.name}</span>
                    </span>
                    <a href={directionsUrl(venue)} target="_blank" rel="noopener noreferrer" className="btn btn-line min-h-11 px-4 py-2 text-[0.95rem]">
                      Directions<span className="sr-only"> to {venue.name}</span>
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ) : null}
        </div>

        <div className="border-b border-gold/40">
          <Note icon={<Plane className="size-5" aria-hidden="true" />} title="By air">
            {travel.airport ?? soon}
          </Note>
          <Note icon={<TrainFront className="size-5" aria-hidden="true" />} title="By train">
            {travel.railway ?? soon}
          </Note>
          <Note icon={<BedDouble className="size-5" aria-hidden="true" />} title="Where to stay">
            {travel.accommodation.length ? (
              <ul className="space-y-2">
                {travel.accommodation.map((a) => (
                  <li key={a.name}>
                    {a.url ? (
                      <a href={a.url} target="_blank" rel="noopener noreferrer" className="underline decoration-gold underline-offset-4">
                        {a.name}
                      </a>
                    ) : (
                      a.name
                    )}
                    {a.note ? <span className="block text-[1rem] text-ivory/75">{a.note}</span> : null}
                  </li>
                ))}
              </ul>
            ) : (
              <span className="text-ivory/70 italic">Recommendations will be shared soon.</span>
            )}
          </Note>
          <Note icon={<CarFront className="size-5" aria-hidden="true" />} title="Parking">
            {travel.parking ?? soon}
          </Note>
          <Note icon={<Phone className="size-5" aria-hidden="true" />} title="Travel help">
            {travel.assistanceContact ? (
              <>
                {travel.assistanceContact.name},{" "}
                <a href={`tel:${travel.assistanceContact.phone.replace(/[^+\d]/g, "")}`} className="underline decoration-gold underline-offset-4">
                  {travel.assistanceContact.phone}
                </a>
              </>
            ) : (
              <span className="text-ivory/70 italic">A contact for travel help will be shared soon.</span>
            )}
          </Note>
        </div>
      </div>
    </section>
  );
}
