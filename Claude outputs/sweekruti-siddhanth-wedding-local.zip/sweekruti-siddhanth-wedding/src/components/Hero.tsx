import { CalendarDays, MapPin } from "lucide-react";
import { weddingConfig } from "@/config/wedding";
import { formatDate } from "@/lib/datetime";
import { BrassLamp, HouseAndPalms, JasmineToran, SeaAtDusk, TempleAndPalms } from "./art";
import { Monogram } from "./Monogram";

function MantapaArch() {
  return (
    <svg viewBox="0 0 400 96" className="block w-full" aria-hidden="true">
      <path
        d="M2 96V86C2 60 44 58 66 42C92 22 150 30 200 6C250 30 308 22 334 42C356 58 398 60 398 86V96Z"
        fill="#67242A"
        stroke="#B58A45"
        strokeWidth={1.5}
      />
      <path
        d="M26 96C26 78 62 74 82 58C106 40 156 46 200 26C244 46 294 40 318 58C338 74 374 78 374 96Z"
        fill="#421319"
        stroke="#B58A45"
        strokeWidth={1}
      />
      <g fill="#E7CE98">
        {[[48, 66], [84, 44], [126, 34], [164, 24], [236, 24], [274, 34], [316, 44], [352, 66]].map(([x, y]) => (
          <circle key={x} cx={x} cy={y} r={1.8} />
        ))}
      </g>
      <path d="M200 0l4 6l-4 6l-4-6Z" fill="#E7CE98" />
    </svg>
  );
}

export function Hero() {
  const { brideName, groomName, weddingDate, location } = weddingConfig;
  const date = weddingDate ? formatDate(weddingDate) : null;
  return (
    <section id="top" className="relative isolate flex min-h-svh flex-col overflow-hidden bg-maroon text-ivory">
      <div className="paisley absolute inset-0 -z-10 opacity-[0.08]" />
      <div className="absolute inset-x-0 top-16 -z-10 border-t border-gold/50">
        <JasmineToran />
      </div>

      <div className="flex flex-1 items-center justify-center px-4 pt-28 pb-[calc(max(24svh,9rem)-2.75rem)] sm:pt-24 lg:pb-[9svh]">
        <div className="hero-rise flex w-full max-w-[46rem] items-end justify-center gap-5">
          <BrassLamp className="mb-2 hidden h-52 shrink-0 lg:block" />
          <div className="w-full max-w-[30rem] sm:max-w-[36rem]">
            <MantapaArch />
            <div className="flex items-stretch">
              <div className="pillar w-3 shrink-0 sm:w-4" />
              <div className="min-w-0 flex-1 bg-maroon px-3 pb-6 text-center sm:px-6">
                <Monogram tone="dark" className="hero-rise -mt-10 w-[5.5rem] sm:-mt-16 sm:w-28" label="S S monogram" />
                <p className="hero-rise mt-2 font-label text-[0.95rem] tracking-[0.18em] text-champagne" style={{ ["--i" as string]: 1 }}>
                  Wedding Invitation
                </p>
                <h1
                  className="hero-rise mt-2 font-display text-[clamp(2.9rem,14vw,3.6rem)] leading-[0.98] font-medium italic sm:text-[3.5rem]"
                  style={{ ["--i" as string]: 2 }}
                >
                  <span className="block sm:inline">{brideName}</span>
                  <span className="block py-1 text-[0.5em] text-gold not-italic sm:inline sm:px-3 sm:text-[0.8em]" aria-label="and">
                    &amp;
                  </span>
                  <span className="block sm:inline">{groomName}</span>
                </h1>
                <p className="hero-rise mx-auto mt-4 max-w-[24rem] text-[1.1rem] leading-relaxed text-pretty text-ivory/90" style={{ ["--i" as string]: 3 }}>
                  With the blessings of our families, we invite you to join us as we celebrate the beginning of our forever.
                </p>
                <dl className="hero-rise mt-4 space-y-1 font-label text-[0.98rem] text-champagne" style={{ ["--i" as string]: 4 }}>
                  <div className="flex items-center justify-center gap-2">
                    <dt className="sr-only">Date</dt>
                    <CalendarDays className="size-4 shrink-0 text-gold" aria-hidden="true" />
                    <dd>{date ? `${date.weekday}, ${date.long}` : "Date to be announced"}</dd>
                  </div>
                  <div className="flex items-center justify-center gap-2">
                    <dt className="sr-only">Place</dt>
                    <MapPin className="size-4 shrink-0 text-gold" aria-hidden="true" />
                    <dd>{location}</dd>
                  </div>
                </dl>
                <a href="#events" className="hero-rise btn btn-gold mt-5" style={{ ["--i" as string]: 5 }}>
                  Explore the celebrations
                </a>
              </div>
              <div className="pillar w-3 shrink-0 sm:w-4" />
            </div>
            <div className="h-2 border border-gold bg-burgundy" />
            <div className="-mx-2 h-2 border border-t-0 border-gold bg-burgundy" />
          </div>
          <BrassLamp className="mb-2 hidden h-52 shrink-0 lg:block" />
        </div>
      </div>

      <div className="absolute inset-x-0 bottom-0 -z-10 h-[24svh] min-h-36">
        <SeaAtDusk className="absolute inset-0 h-full w-full" />
        <HouseAndPalms className="absolute bottom-0 -left-10 h-[82%] sm:left-0 sm:h-full" />
        <TempleAndPalms className="absolute -right-12 bottom-0 h-[82%] sm:right-0 sm:h-full" />
      </div>
    </section>
  );
}
