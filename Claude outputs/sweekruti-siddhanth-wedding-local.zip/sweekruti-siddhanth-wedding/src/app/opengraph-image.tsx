import { readFile } from "node:fs/promises";
import path from "node:path";
import { ImageResponse } from "next/og";
import { weddingConfig } from "@/config/wedding";
import { formatDate } from "@/lib/datetime";
import { monogramSvg } from "@/lib/monogram-svg";

export const alt = "Sweekruti & Siddhanth, wedding invitation";
export const size = { width: 1200, height: 630 };
export const contentType = "image/png";

const font = (file: string) => readFile(path.join(process.cwd(), "src", "fonts", file));

export default async function OpengraphImage() {
  const [italic, label] = await Promise.all([font("cormorant-garamond-latin-500-italic.woff"), font("marcellus-latin-400-normal.woff")]);
  const seal = `data:image/svg+xml;base64,${Buffer.from(monogramSvg("seal", "og").replace('width="100%" height="100%"', 'width="200" height="200"')).toString("base64")}`;
  const when = weddingConfig.weddingDate ? formatDate(weddingConfig.weddingDate).long : null;
  return new ImageResponse(
    (
      <div style={{ width: "100%", height: "100%", display: "flex", background: "#421319", padding: 28 }}>
        <div style={{ flex: 1, display: "flex", border: "2px solid #B58A45", padding: 10 }}>
          <div
            style={{
              flex: 1,
              display: "flex",
              flexDirection: "column",
              alignItems: "center",
              justifyContent: "center",
              border: "1px solid #B58A45",
              color: "#FBF3E4",
            }}
          >
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src={seal} width={170} height={170} alt="" />
            <div style={{ marginTop: 22, fontFamily: "Marcellus", fontSize: 30, letterSpacing: 6, color: "#E7CE98" }}>Wedding Invitation</div>
            <div style={{ marginTop: 10, fontFamily: "Cormorant", fontStyle: "italic", fontSize: 104, lineHeight: 1.1 }}>
              {`${weddingConfig.brideName} & ${weddingConfig.groomName}`}
            </div>
            <div style={{ marginTop: 18, fontFamily: "Marcellus", fontSize: 28, color: "#E7CE98" }}>
              {when ? `${when}, ${weddingConfig.location}` : weddingConfig.location}
            </div>
          </div>
        </div>
      </div>
    ),
    {
      ...size,
      fonts: [
        { name: "Cormorant", data: italic, style: "italic", weight: 500 },
        { name: "Marcellus", data: label, style: "normal", weight: 400 },
      ],
    },
  );
}
