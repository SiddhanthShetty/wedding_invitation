import { ImageResponse } from "next/og";
import { monogramSvg } from "@/lib/monogram-svg";

export const size = { width: 180, height: 180 };
export const contentType = "image/png";

export default function AppleIcon() {
  const seal = `data:image/svg+xml;base64,${Buffer.from(monogramSvg("seal", "apple").replace('width="100%" height="100%"', 'width="200" height="200"')).toString("base64")}`;
  return new ImageResponse(
    (
      <div style={{ width: "100%", height: "100%", display: "flex", alignItems: "center", justifyContent: "center", background: "#421319" }}>
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img src={seal} width={168} height={168} alt="" />
      </div>
    ),
    size,
  );
}
