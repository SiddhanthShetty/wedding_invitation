import { coupleNames, weddingConfig } from "@/config/wedding";
import { formatDate } from "@/lib/datetime";
import { weddingInstant } from "@/lib/wedding";
import { Countdown } from "@/components/Countdown";
import { Events } from "@/components/Events";
import { Footer } from "@/components/Footer";
import { Gallery } from "@/components/Gallery";
import { Hero } from "@/components/Hero";
import { Monogram } from "@/components/Monogram";
import { Music } from "@/components/Music";
import { MusicProvider } from "@/components/MusicProvider";
import { Nav } from "@/components/Nav";
import { Rsvp } from "@/components/Rsvp";
import { Share } from "@/components/Share";
import { Story } from "@/components/Story";
import { Venue } from "@/components/Venue";

export default function Home() {
  const target = weddingInstant();
  const date = weddingConfig.weddingDate ? formatDate(weddingConfig.weddingDate) : null;
  const respondBy = weddingConfig.rsvp.respondBy ? formatDate(weddingConfig.rsvp.respondBy).long : null;
  return (
    <MusicProvider tracks={weddingConfig.music}>
      <Nav names={coupleNames} monogram={<Monogram tone="dark" className="size-10" />} />
      <main>
        <Hero />
        <Story />
        <Events />
        <Venue />
        <Music />
        <Rsvp events={weddingConfig.events.map((e) => ({ id: e.id, name: e.name }))} respondBy={respondBy} />
        <Countdown targetMs={target ? target.getTime() : null} dateLabel={date ? `${date.weekday}, ${date.long} (${weddingConfig.timezone === "Asia/Kolkata" ? "India time" : weddingConfig.timezone})` : null} />
        <Gallery items={weddingConfig.gallery} />
        <Share />
      </main>
      <Footer />
    </MusicProvider>
  );
}
