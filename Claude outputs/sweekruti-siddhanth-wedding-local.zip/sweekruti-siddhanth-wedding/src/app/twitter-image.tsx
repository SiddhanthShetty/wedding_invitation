import OpengraphImage from "./opengraph-image";

export const alt = "Sweekruti & Siddhanth, wedding invitation";
export const size = { width: 1200, height: 630 };
export const contentType = "image/png";

export default OpengraphImage;
