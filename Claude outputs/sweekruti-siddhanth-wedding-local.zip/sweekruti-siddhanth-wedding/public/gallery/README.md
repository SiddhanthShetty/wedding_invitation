Put gallery photographs in this folder (JPEG, PNG or WebP; around 1600 px on the long side is plenty).
Then set `src`, `width` and `height` for each one in `src/config/wedding.ts`, for example:

    { category: "couple", src: "/gallery/couple-1.jpg", alt: "Sweekruti and Siddhanth at the beach", width: 1200, height: 1500 }

The site resizes them and serves WebP/AVIF automatically.
